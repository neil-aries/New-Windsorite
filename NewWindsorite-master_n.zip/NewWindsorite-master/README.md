New Windsorite
==============

For any newcomer, there would be certain issues faced by them such as getting accustomed to the general public services in the city of Windsor. Moreover, a newcomer would lack acquaintances to support while they transit to a new city like Windsor. 
This website helps in the eradication of the above-mentioned issues. 
The system provides an user-friendly web application which can interact with the new Windsorite to provide the public services in real time. 
The website also recommends various services of the City of Windsor to its registered users using Windsor Open Data API.
The system is a comprehensive guide to the newcomers at the city of Windsor.
This is an interactive website that would gather the user characteristics and preferences of the user via chatting with a bot and recommend some of the public services as an acquaintance.


## Technologies Used:

1. IBM Bluemix
2. Watson Cognitive Services
3. Cloudant DB
4. Windsor Open Data API.
5. Java
6. BootStrap
7. HTML, CSS
8. JS
9. AJAX
