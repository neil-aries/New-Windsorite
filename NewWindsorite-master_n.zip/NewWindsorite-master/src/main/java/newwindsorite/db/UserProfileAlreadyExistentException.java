package newwindsorite.db;

public class UserProfileAlreadyExistentException extends Exception {
	
	public UserProfileAlreadyExistentException(String message) {
		super(message);
	}

}
